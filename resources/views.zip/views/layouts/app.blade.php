<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <link rel="shortcut icon" href="/images/favicon.ico" type="image/x-icon">
        <title>{{ $CRM_ISS->nilai }}</title>


        <!-- style -->
        <link rel="stylesheet" href="/resources/css/mystyle.css">
        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">
        
        <!-- Styles -->
        @livewireStyles
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css">
        <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.4.0/css/responsive.jqueryui.min.css">
        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

        <!-- Scripts -->
        @vite(['resources/css/app.css', 'resources/js/app.js'])
        <style>
            /* Chrome, Safari, Edge, Opera */
            input::-webkit-outer-spin-button,
            input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
            }

            .pointer {cursor: pointer;}

            /* .selector {
                position: relative;
                --bs-blue: #0d6efd;
                --bs-indigo: #6610f2;
                --bs-purple: #6f42c1;
                --bs-pink: #d63384;
                --bs-red: #dc3545;
                --bs-orange: #fd7e14;
                --bs-yellow: #ffc107;
                --bs-green: #198754;
                --bs-teal: #20c997;
                --bs-cyan: #0dcaf0;
                --bs-black: #000;
                --bs-white: #fff;
                --bs-gray: #6c757d;
                --bs-gray-dark: #343a40;
                --bs-gray-100: #f8f9fa;
                --bs-gray-200: #e9ecef;
                --bs-gray-300: #dee2e6;
                --bs-gray-400: #ced4da;
                --bs-gray-500: #adb5bd;
                --bs-gray-600: #6c757d;
                --bs-gray-700: #495057;
                --bs-gray-800: #343a40;
                --bs-gray-900: #212529;
                --bs-primary: #0d6efd;
                --bs-secondary: #6c757d;
                --bs-success: #198754;
                --bs-info: #0dcaf0;
                --bs-warning: #ffc107;
                --bs-danger: #dc3545;
                --bs-light: #f8f9fa;
                --bs-dark: #212529;
                --bs-primary-rgb: 13,110,253;
                --bs-secondary-rgb: 108,117,125;
                --bs-success-rgb: 25,135,84;
                --bs-info-rgb: 13,202,240;
                --bs-warning-rgb: 255,193,7;
                --bs-danger-rgb: 220,53,69;
                --bs-light-rgb: 248,249,250;
                --bs-dark-rgb: 33,37,41;
                --bs-white-rgb: 255,255,255;
                --bs-black-rgb: 0,0,0;
                --bs-body-color-rgb: 33,37,41;
                --bs-body-bg-rgb: 255,255,255;
                --bs-font-sans-serif: system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue","Noto Sans","Liberation Sans",Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";
                --bs-font-monospace: SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono","Courier New",monospace;
                --bs-gradient: linear-gradient(180deg, rgba(255, 255, 255, 0.15), rgba(255, 255, 255, 0));
                --bs-body-font-family: var(--bs-font-sans-serif);
                --bs-body-font-size: 1rem;
                --bs-body-font-weight: 400;
                --bs-body-line-height: 1.5;
                --bs-body-color: #212529;
                --bs-body-bg: #fff;
                --bs-border-width: 1px;
                --bs-border-style: solid;
                --bs-border-color: #dee2e6;
                --bs-border-color-translucent: rgba(0, 0, 0, 0.175);
                --bs-border-radius: 0.375rem;
                --bs-border-radius-sm: 0.25rem;
                --bs-border-radius-lg: 0.5rem;
                --bs-border-radius-xl: 1rem;
                --bs-border-radius-2xl: 2rem;
                --bs-border-radius-pill: 50rem;
                --bs-link-color: #0d6efd;
                --bs-link-hover-color: #0a58ca;
                --bs-code-color: #d63384;
                --bs-highlight-bg: #fff3cd;
                --range-thumb-size: 36px;
                -webkit-text-size-adjust: 100%;
                -webkit-tap-highlight-color: transparent;
                -webkit-font-smoothing: antialiased;
                --bs-bg-opacity: 1;
                box-sizing: border-box;
                border-style: solid;
                --tw-border-spacing-x: 0;
                --tw-border-spacing-y: 0;
                --tw-translate-x: 0;
                --tw-translate-y: 0;
                --tw-rotate: 0;
                --tw-skew-x: 0;
                --tw-skew-y: 0;
                --tw-scale-x: 1;
                --tw-scale-y: 1;
                --tw-pan-x: ;
                --tw-pan-y: ;
                --tw-pinch-zoom: ;
                --tw-scroll-snap-strictness: proximity;
                --tw-ordinal: ;
                --tw-slashed-zero: ;
                --tw-numeric-figure: ;
                --tw-numeric-spacing: ;
                --tw-numeric-fraction: ;
                --tw-ring-inset: ;
                --tw-ring-offset-width: 0px;
                --tw-ring-offset-color: #fff;
                --tw-ring-color: rgb(59 130 246 / 0.5);
                --tw-ring-offset-shadow: 0 0 #0000;
                --tw-ring-shadow: 0 0 #0000;
                --tw-blur: ;
                --tw-brightness: ;
                --tw-contrast: ;
                --tw-grayscale: ;
                --tw-hue-rotate: ;
                --tw-invert: ;
                --tw-saturate: ;
                --tw-sepia: ;
                --tw-drop-shadow: ;
                --tw-backdrop-blur: ;
                --tw-backdrop-brightness: ;
                --tw-backdrop-contrast: ;
                --tw-backdrop-grayscale: ;
                --tw-backdrop-hue-rotate: ;
                --tw-backdrop-invert: ;
                --tw-backdrop-opacity: ;
                --tw-backdrop-saturate: ;
                --tw-backdrop-sepia: ;
                --calendarPadding: 24px;
                --daySize: 36px;
                --daysWidth: calc(var(--daySize)*7);
                font-family: inherit;
                font-weight: inherit;
                margin: 0;
                padding-right: .5rem!important;
                padding-left: .5rem!important;
                padding-top: .25rem!important;
                padding-bottom: .25rem!important;
                appearance: none;
                border-width: 1px;
                --tw-bg-opacity: 1;
                background-color: rgb(255 255 255 / var(--tw-bg-opacity));
                font-size: 0.875rem;
                --tw-text-opacity: 1;
                color: rgb(30 41 59 / var(--tw-text-opacity));
                border-radius: 0.25rem;
                --tw-border-opacity: 1;
                border-color: rgb(226 232 240 / var(--tw-border-opacity));
                line-height: 1.25rem;
                --tw-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05);
                --tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);
                box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
                width: 75%;
            }

            .selector:before {
                content: attr(data-date);
            }

            .selector::-webkit-datetime-edit, .selector::-webkit-inner-spin-button, .selector::-webkit-clear-button {
                display: none;
            }

            .selector::-webkit-calendar-picker-indicator {
                position: relative;
                /* margin-right: 20px; */
                /* top: 50%;
                width: 1em;
                transform: translateY(-50%);
                left: 5rem;
                cursor: pointer; */
            /* } */
            .selector {
                position: relative;
                width: 75%; /* Sesuaikan lebar dengan kebutuhan Anda */
            }

            .selector:before {
                content: attr(data-date);
            }

            .selector::-webkit-datetime-edit,
            .selector::-webkit-inner-spin-button,
            .selector::-webkit-clear-button {
                display: none;
            }

            .selector::-webkit-calendar-picker-indicator {
                position: absolute;
                top: 50%;
                width: 1em;
                transform: translateY(-50%);
                left: 6rem;
                cursor: pointer;
            }
        </style>
    </head>
    <body
        class="font-inter antialiased bg-slate-100 text-slate-600"
        :class="{ 'sidebar-expanded': sidebarExpanded }"
        x-data="{ sidebarOpen: false, sidebarExpanded: localStorage.getItem('sidebar-expanded') == 'true' }"
        x-init="$watch('sidebarExpanded', value => localStorage.setItem('sidebar-expanded', value))"    
    >
        @include('sweetalert::alert')
        <script>
            if (localStorage.getItem('sidebar-expanded') == 'true') {
                document.querySelector('body').classList.add('sidebar-expanded');
            } else {
                document.querySelector('body').classList.remove('sidebar-expanded');
            }
        </script>

        <!-- Page wrapper -->
        <div class="flex h-screen overflow-hidden">

            <x-app.sidebar />

            <!-- Content area -->
            <div class="relative flex flex-col flex-1 overflow-y-auto overflow-x-hidden @if($attributes['background']){{ $attributes['background'] }}@endif" x-ref="contentarea">

                <x-app.header />

                <main>
                    {{ $slot }}
                </main>

            </div>

        </div>

        @livewireScripts
        <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
        <script src="https://cdn.datatables.net/responsive/2.4.0/js/dataTables.responsive.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.3/moment.min.js"></script>
        {{-- <script type="text/javascript" src="my.js"></script> --}}
        

        <script>
            function formatDate(date){
                let d = new Date(date);
                const formattedDate = d.getFullYear() + "-" + ("0"+(d.getMonth()+1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2);
                return formattedDate;
            }

            function formatCurrency(num) {
                var num_parts = num.toString().split(".");
                num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                return 'IDR ' + num_parts.join(".");
            }
            function divider(num) {
                var num_parts = num.toString().split(".");
                num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                return ' ' + num_parts.join(".");
            }
            function divider1(num) {
                return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
            }
            function newDivider(num) {
                var numString = num.toString();
                var num_parts = numString.split(".");

                // Memisahkan dua digit terakhir dari bagian desimal
                var lastTwoDecimals = num_parts[1] ? num_parts[1].substr(0, 2) : "00";
                
                // Menggabungkan dua digit pertama desimal ke bagian yang sudah diformat
                var formattedNum = num_parts[0] + "." + lastTwoDecimals;

                // Memformat bagian sebelum titik desimal dengan titik sebagai pemisah ribuan
                formattedNum = formattedNum.replace(/\B(?=(\d{3})+(?!\d))/g, ".");

                return formattedNum;
            }
            function newDivider1(num) {
                // Mengkonversi angka menjadi string dan memisahkan bagian desimal
                var numString = num.toString();
                var num_parts = numString.split(".");

                // Bagian depan angka (tanpa desimal)
                var formattedNum = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ".");

                return formattedNum;
            }
            function newDivider2(num) {
                // Mengkonversi angka menjadi string dan memisahkan bagian desimal
                var numString = num.toString();
                var num_parts = numString.split(".");

                // Bagian depan angka (tanpa desimal)
                var formattedNum = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, "");

                return formattedNum;
            }
            const loadFile = function (event) {
                const output = document.getElementById("output");
                output.src = URL.createObjectURL(event.target.files[0]);
                output.onload = function () {
                    URL.revokeObjectURL(output.src); // free memory
                };
            };

            const loadFileMultiple = function (event, idView) {
                const output = document.getElementById(idView);
                output.src = URL.createObjectURL(event.target.files[0]);
                output.onload = function () {
                    URL.revokeObjectURL(output.src); // free memory
                };
            };

            $('.selector').on("change", function () {
                if (this.value !== "") {
                    this.setAttribute(
                        "data-date",
                        moment(this.value, "YYYY-MM-DD").format(this.getAttribute("data-date-format"))
                    );
                } else {
                    this.removeAttribute("data-date");
                }
            }).trigger("change");

            // function allinDivider(num) {
            //     const parts = num.toString().split('.');
            //     parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                
            //     if (parts[1]) {
            //         parts[1] = parts[1].substring(0, 2).replace('.', ',');
            //     }
                
            //     return parts.join(',');
            // }

            function allinDivider(num) {
                const parts = num.toString().split('.');
                parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ".");

                if (parts[1]) {
                    // Hapus nol di akhir desimal dan batasi hingga 4 digit desimal
                    parts[1] = parts[1].replace(/0+$/, '').substring(0, 4);
                }

                return parts.length > 1 && parts[1] !== '' ? parts.join(',') : parts[0];
            }

            function textToInputFormat(text) {
                return text.replace(/&/g, "&amp;")
                        .replace(/"/g, "&quot;")
                        .replace(/'/g, "&#39;")
                        .replace(/</g, "&lt;")
                        .replace(/>/g, "&gt;");
            }

            // Fungsi untuk menambahkan titik sebagai pemisah ribuan
            function addThousandSeparator(num) {
                // Memisahkan bagian angka sebelum koma dan setelah koma
                const parts = num.toString().split(',');
                parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                
                // Jika ada bagian desimal
                if (parts[1]) {
                    // Mengambil hanya 4 digit pertama setelah koma
                    parts[1] = parts[1].substring(0, 4);
                }
                
                return parts.join(',');
            }

            // Fungsi untuk memastikan input hanya angka dan koma
            function allowOnlyNumbers(event) {
                const allowedKeys = [8, 9, 17, 44]; // Backspace, Tab, Ctrl, dan Koma (,)

                if (event.keyCode && allowedKeys.includes(event.keyCode)) return true;

                const charCode = event.which ? event.which : event.keyCode;

                // Memeriksa karakter apakah angka atau koma
                if ((charCode < 48 || charCode > 57) && charCode !== 44) return false;

                return true;
            }

            // Event listener untuk input dengan kelas numeric-input
            document.querySelectorAll('.numeric-input').forEach(function(input) {
                input.addEventListener('input', function(event) {
                    let inputValue = event.target.value;

                    // Menghapus semua karakter selain angka dan koma
                    inputValue = inputValue.replace(/[^\d,]/g, '');

                    // Memastikan hanya satu koma yang diizinkan
                    const commaCount = inputValue.split(',').length - 1;
                    if (commaCount > 1) {
                        inputValue = inputValue.replace(/,/g, ''); // Hapus semua koma tambahan
                    }

                    event.target.value = addThousandSeparator(inputValue);
                });

                input.addEventListener('keypress', function(event) {
                    if (!allowOnlyNumbers(event)) {
                        event.preventDefault();
                    }
                });
            });

            // Fungsi untuk memastikan input hanya angka, koma, dan tanda minus
            function allowExtendedNumbers(event) {
                const allowedKeys = [8, 9, 17, 44, 45]; // Backspace, Tab, Ctrl, Koma (,), dan Minus (-)

                if (event.keyCode && allowedKeys.includes(event.keyCode)) return true;

                const charCode = event.which ? event.which : event.keyCode;

                // Memeriksa karakter apakah angka, koma, atau tanda minus
                if ((charCode < 48 || charCode > 57) && charCode !== 44 && charCode !== 45) return false;

                return true;
            }

            // Event listener untuk input dengan kelas extended-numeric-input
            document.querySelectorAll('.extended-numeric-input').forEach(function(input) {
                input.addEventListener('input', function(event) {
                    let inputValue = event.target.value;

                    // Menghapus semua karakter selain angka, koma, dan tanda minus
                    inputValue = inputValue.replace(/[^-\d,]/g, '');

                    // Memastikan hanya satu koma yang diizinkan
                    const commaCount = inputValue.split(',').length - 1;
                    if (commaCount > 1) {
                        inputValue = inputValue.replace(/,/g, ''); // Hapus semua koma tambahan
                    }

                    // Memastikan hanya satu tanda minus yang diizinkan, dan harus di awal string
                    const minusCount = inputValue.split('-').length - 1;
                    if (minusCount > 1 || (minusCount === 1 && inputValue.indexOf('-') > 0)) {
                        inputValue = inputValue.replace(/-/g, ''); // Hapus semua tanda minus tambahan
                    }

                    event.target.value = addThousandSeparator(inputValue);
                });

                input.addEventListener('keypress', function(event) {
                    if (!allowExtendedNumbers(event)) {
                        event.preventDefault();
                    }
                });
            });

            function allowOnlyNumbersAndDot(event) {
                const allowedKeys = [8, 9, 17, 46]; // Backspace, Tab, Ctrl, dan Titik (.)

                if (event.keyCode && allowedKeys.includes(event.keyCode)) return true;

                const charCode = event.which ? event.which : event.keyCode;

                // Memeriksa karakter apakah angka atau titik
                if ((charCode < 48 || charCode > 57) && charCode !== 46) return false;

                return true;
            }

            // Event listener untuk input dengan kelas numeric-input
            document.querySelectorAll('.numeric1-input').forEach(function(input) {
                input.addEventListener('input', function(event) {
                    let inputValue = event.target.value;

                    // Menghapus semua karakter selain angka dan titik
                    inputValue = inputValue.replace(/[^\d.]/g, '');

                    event.target.value = inputValue;
                });

                input.addEventListener('keypress', function(event) {
                    if (!allowOnlyNumbersAndDot(event)) {
                        event.preventDefault();
                    }
                });
            });
        </script>
        @yield('js-page')
    </body>
</html>
