<div>
    <div class="bg-white shadow-lg rounded-sm border border-slate-200 p-5 min-w-60">
        <div class="grid md:grid-cols-2 xl:grid-cols-1 gap-6">
            <!-- Group 1 -->
            <div>
                <div class="text-sm text-slate-800 font-semibold mb-3">Category</div>
                <ul class="text-sm font-medium space-y-2">
                    <li>
                        <a class="text-indigo-500" href="#0">View All</a>
                    </li>
                    <li>
                        <a class="text-slate-600 hover:text-slate-700" href="#0">Computer / IT</a>
                    </li>
                    <li>
                        <a class="text-slate-600 hover:text-slate-700" href="#0">Lighting / Electrical</a>
                    </li>
                    <li>
                        <a class="text-slate-600 hover:text-slate-700" href="#0">Logistic Supply</a>
                    </li>
                    <li>
                        <a class="text-slate-600 hover:text-slate-700" href="#0">Office Supply</a>
                    </li>
                    <li>
                        <a class="text-slate-600 hover:text-slate-700" href="#0">Pantry Supply</a>
                    </li>
                    <li>
                        <a class="text-slate-600 hover:text-slate-700" href="#0">Techinical Supply</a>
                    </li>
                </ul>
            </div>
            {{-- <!-- Price Range -->
            <div>
                <div class="text-sm text-slate-800 font-semibold mb-3">Price Range</div>
                <label class="sr-only">Price</label>
                <select class="form-select w-full">
                    <option>Less than $20</option>
                    <option>$20 - $40</option>
                    <option>$40 - $80</option>
                    <option>More than $80</option>
                </select>
            </div>
            <!-- Group 3 -->
            <div>
                <div class="text-sm text-slate-800 font-semibold mb-3">Multi Select</div>
                <ul class="space-y-2">
                    <li>
                        <label class="flex items-center">
                            <input type="checkbox" class="form-checkbox" checked />
                            <span class="text-sm text-slate-600 font-medium ml-2">Apps / Software</span>
                        </label>
                    </li>
                    <li>
                        <label class="flex items-center">
                            <input type="checkbox" class="form-checkbox" checked />
                            <span class="text-sm text-slate-600 font-medium ml-2">Education</span>
                        </label>
                    </li>
                    <li>
                        <label class="flex items-center">
                            <input type="checkbox" class="form-checkbox" />
                            <span class="text-sm text-slate-600 font-medium ml-2">Books & Writing</span>
                        </label>
                    </li>
                    <li>
                        <label class="flex items-center">
                            <input type="checkbox" class="form-checkbox" />
                            <span class="text-sm text-slate-600 font-medium ml-2">Drawing / Painting</span>
                        </label>
                    </li>
                </ul>
            </div>
            <!-- Group 4 -->
            <div>
                <div class="text-sm text-slate-800 font-semibold mb-3">Sort By Rating</div>
                <ul class="space-y-2">
                    <li>
                        <!-- Rating button -->
                        <button class="flex items-center space-x-2 mr-2">
                            <!-- Stars -->
                            <div class="flex space-x-1">
                                <svg class="w-4 h-4 fill-current text-amber-500" viewBox="0 0 16 16">
                                    <path d="M10 5.934L8 0 6 5.934H0l4.89 3.954L2.968 16 8 12.223 13.032 16 11.11 9.888 16 5.934z" />
                                </svg>
                                <svg class="w-4 h-4 fill-current text-amber-500" viewBox="0 0 16 16">
                                    <path d="M10 5.934L8 0 6 5.934H0l4.89 3.954L2.968 16 8 12.223 13.032 16 11.11 9.888 16 5.934z" />
                                </svg>
                                <svg class="w-4 h-4 fill-current text-amber-500" viewBox="0 0 16 16">
                                    <path d="M10 5.934L8 0 6 5.934H0l4.89 3.954L2.968 16 8 12.223 13.032 16 11.11 9.888 16 5.934z" />
                                </svg>
                                <svg class="w-4 h-4 fill-current text-amber-500" viewBox="0 0 16 16">
                                    <path d="M10 5.934L8 0 6 5.934H0l4.89 3.954L2.968 16 8 12.223 13.032 16 11.11 9.888 16 5.934z" />
                                </svg>
                                <svg class="w-4 h-4 fill-current text-slate-300" viewBox="0 0 16 16">
                                    <path d="M10 5.934L8 0 6 5.934H0l4.89 3.954L2.968 16 8 12.223 13.032 16 11.11 9.888 16 5.934z" />
                                </svg>
                            </div>
                            <div class="inline-flex text-sm text-slate-500 italic"><span class="sr-only">4 Stars</span> And up</div>
                        </button>
                    </li>
                    <li>
                        <!-- Rating button -->
                        <button class="flex items-center space-x-2 mr-2">
                            <!-- Stars -->
                            <div class="flex space-x-1">
                                <svg class="w-4 h-4 fill-current text-amber-500" viewBox="0 0 16 16">
                                    <path d="M10 5.934L8 0 6 5.934H0l4.89 3.954L2.968 16 8 12.223 13.032 16 11.11 9.888 16 5.934z" />
                                </svg>
                                <svg class="w-4 h-4 fill-current text-amber-500" viewBox="0 0 16 16">
                                    <path d="M10 5.934L8 0 6 5.934H0l4.89 3.954L2.968 16 8 12.223 13.032 16 11.11 9.888 16 5.934z" />
                                </svg>
                                <svg class="w-4 h-4 fill-current text-amber-500" viewBox="0 0 16 16">
                                    <path d="M10 5.934L8 0 6 5.934H0l4.89 3.954L2.968 16 8 12.223 13.032 16 11.11 9.888 16 5.934z" />
                                </svg>
                                <svg class="w-4 h-4 fill-current text-slate-300" viewBox="0 0 16 16">
                                    <path d="M10 5.934L8 0 6 5.934H0l4.89 3.954L2.968 16 8 12.223 13.032 16 11.11 9.888 16 5.934z" />
                                </svg>
                                <svg class="w-4 h-4 fill-current text-slate-300" viewBox="0 0 16 16">
                                    <path d="M10 5.934L8 0 6 5.934H0l4.89 3.954L2.968 16 8 12.223 13.032 16 11.11 9.888 16 5.934z" />
                                </svg>
                            </div>
                            <div class="inline-flex text-sm text-slate-500 italic"><span class="sr-only">3 Stars</span> And up</div>
                        </button>
                    </li>
                    <li>
                        <!-- Rating button -->
                        <button class="flex items-center space-x-2 mr-2">
                            <!-- Stars -->
                            <div class="flex space-x-1">
                                <svg class="w-4 h-4 fill-current text-amber-500" viewBox="0 0 16 16">
                                    <path d="M10 5.934L8 0 6 5.934H0l4.89 3.954L2.968 16 8 12.223 13.032 16 11.11 9.888 16 5.934z" />
                                </svg>
                                <svg class="w-4 h-4 fill-current text-amber-500" viewBox="0 0 16 16">
                                    <path d="M10 5.934L8 0 6 5.934H0l4.89 3.954L2.968 16 8 12.223 13.032 16 11.11 9.888 16 5.934z" />
                                </svg>
                                <svg class="w-4 h-4 fill-current text-slate-300" viewBox="0 0 16 16">
                                    <path d="M10 5.934L8 0 6 5.934H0l4.89 3.954L2.968 16 8 12.223 13.032 16 11.11 9.888 16 5.934z" />
                                </svg>
                                <svg class="w-4 h-4 fill-current text-slate-300" viewBox="0 0 16 16">
                                    <path d="M10 5.934L8 0 6 5.934H0l4.89 3.954L2.968 16 8 12.223 13.032 16 11.11 9.888 16 5.934z" />
                                </svg>
                                <svg class="w-4 h-4 fill-current text-slate-300" viewBox="0 0 16 16">
                                    <path d="M10 5.934L8 0 6 5.934H0l4.89 3.954L2.968 16 8 12.223 13.032 16 11.11 9.888 16 5.934z" />
                                </svg>
                            </div>
                            <div class="inline-flex text-sm text-slate-500 italic"><span class="sr-only">2 Stars</span> And up</div>
                        </button>
                    </li>
                    <li>
                        <!-- Rating button -->
                        <button class="flex items-center space-x-2 mr-2">
                            <!-- Stars -->
                            <div class="flex space-x-1">
                                <svg class="w-4 h-4 fill-current text-amber-500" viewBox="0 0 16 16">
                                    <path d="M10 5.934L8 0 6 5.934H0l4.89 3.954L2.968 16 8 12.223 13.032 16 11.11 9.888 16 5.934z" />
                                </svg>
                                <svg class="w-4 h-4 fill-current text-slate-300" viewBox="0 0 16 16">
                                    <path d="M10 5.934L8 0 6 5.934H0l4.89 3.954L2.968 16 8 12.223 13.032 16 11.11 9.888 16 5.934z" />
                                </svg>
                                <svg class="w-4 h-4 fill-current text-slate-300" viewBox="0 0 16 16">
                                    <path d="M10 5.934L8 0 6 5.934H0l4.89 3.954L2.968 16 8 12.223 13.032 16 11.11 9.888 16 5.934z" />
                                </svg>
                                <svg class="w-4 h-4 fill-current text-slate-300" viewBox="0 0 16 16">
                                    <path d="M10 5.934L8 0 6 5.934H0l4.89 3.954L2.968 16 8 12.223 13.032 16 11.11 9.888 16 5.934z" />
                                </svg>
                                <svg class="w-4 h-4 fill-current text-slate-300" viewBox="0 0 16 16">
                                    <path d="M10 5.934L8 0 6 5.934H0l4.89 3.954L2.968 16 8 12.223 13.032 16 11.11 9.888 16 5.934z" />
                                </svg>
                            </div>
                            <div class="inline-flex text-sm text-slate-500 italic"><span class="sr-only">1 Stars</span> And up</div>
                        </button>
                    </li>
                </ul>
            </div> --}}
        </div>
    </div>
</div>